﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin.Controls;
using System.Data.SqlClient;
using System.Net;
using System.Net.Mail;

namespace Proje_01
{

    public partial class UrunSatForm : MaterialForm
    {
        public UrunSatForm()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection();
        SqlDataAdapter da = new SqlDataAdapter();
        SqlCommand com = new SqlCommand();
        DataSet ds = new DataSet();
        private void UrunSatForm_Load(object sender, EventArgs e)
        {
            

            combobox();
            cari();
           
        }
        void combobox()
        {
            SqlConnection baglanti = new SqlConnection();
            baglanti.ConnectionString = "server=DESKTOP-8JE6KH6\\SQLEXPRESS; Initial Catalog=Proje_01;Integrated Security=SSPI";
            SqlCommand komut = new SqlCommand();
            komut.CommandText = "SELECT *FROM tbl_urun";
            komut.Connection = baglanti;
            komut.CommandType = CommandType.Text;

            SqlDataReader dr;
            baglanti.Open();
            dr = komut.ExecuteReader();
            while (dr.Read())
            {
                comboBox1.Items.Add(dr["Adi"]);
            }
            baglanti.Close();
        }
        void cari()
        {
            SqlConnection baglanti = new SqlConnection();
            baglanti.ConnectionString = "server=DESKTOP-8JE6KH6\\SQLEXPRESS; Initial Catalog=Proje_01;Integrated Security=SSPI";
            SqlCommand komut = new SqlCommand();
            komut.CommandText = "SELECT *FROM tbl_musteri";
            komut.Connection = baglanti;
            komut.CommandType = CommandType.Text;

            SqlDataReader dr;
            baglanti.Open();
            dr = komut.ExecuteReader();
            while (dr.Read())
            {
                comboBox2.Items.Add(dr["Cari"]);
            }
            baglanti.Close();
        }
        void mail()
        {










        }
        void griddoldur()
        {
            if (comboBox1.Text != "" && comboBox2.Text != "" && textBox1.Text != "")
            {
                con = new SqlConnection("server=DESKTOP-8JE6KH6\\SQLEXPRESS; Initial Catalog=Proje_01;Integrated Security=SSPI");
                da = new SqlDataAdapter("Select * From tbl_urun where Adi = '" + comboBox1.Text + "'", con);
                ds = new DataSet();
                con.Open();
                da.Fill(ds, "Personel");
                dataGridView1.DataSource = ds.Tables["Personel"];
                con.Close();
            }
        }
        void griddoldur2()
        {
            if (comboBox1.Text != "" && comboBox2.Text != "" && textBox1.Text != "")
            {
                con = new SqlConnection("server=DESKTOP-8JE6KH6\\SQLEXPRESS; Initial Catalog=Proje_01;Integrated Security=SSPI");
                da = new SqlDataAdapter("Select * From tbl_musteri where Cari = '" + comboBox2.Text + "'", con);
                ds = new DataSet();
                con.Open();
                da.Fill(ds, "Personel");
                dataGridView2.DataSource = ds.Tables["Personel"];
                con.Close();
            }
        }
        void getir()
        {
            string deger1 = dataGridView1.CurrentRow.Cells["Fiyat"].Value.ToString();
            textBox2.Text = deger1;
            string deger2 = dataGridView1.CurrentRow.Cells["Adi"].Value.ToString();
            label13.Text = deger2;
            string deger3 = dataGridView1.CurrentRow.Cells["Barkod"].Value.ToString();
            label12.Text = deger3;
            string deger4 = dataGridView2.CurrentRow.Cells["Adi"].Value.ToString();
            label15.Text = deger4;
            string deger5 = dataGridView2.CurrentRow.Cells["Cari"].Value.ToString();
            label14.Text = deger5;
            string deger6 = dataGridView1.CurrentRow.Cells["Mikar"].Value.ToString();
            label16.Text = deger6;
            string deger7 = dataGridView2.CurrentRow.Cells["Mail"].Value.ToString();
            textBox3.Text = deger7;
        }
        void güncelle()
        {
            if (textBox4.Text != "")
            {
            SqlConnection con;
            SqlCommand cmd, cmk;
            SqlDataReader dr;
            con = new SqlConnection("server=DESKTOP-8JE6KH6\\SQLEXPRESS; Initial Catalog=Proje_01;Integrated Security=SSPI");
            cmd = new SqlCommand();
            con.Open();
            cmd.Connection = con;
            cmd.CommandText = "UPDATE tbl_urun SET Mikar=@miktar  where Barkod=@barkod";
            cmd.Parameters.AddWithValue("@miktar", textBox4.Text);
            cmd.Parameters.AddWithValue("@barkod", label12.Text);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Satış İşlemi Gerçekleşmiştir...");
            }
            else
            {
                MessageBox.Show("Lütfen Alanları Doldurunuz...");
            }






        }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {

            if (comboBox1.Text != ""&& comboBox2.Text != ""&& textBox1.Text != "")
            {
            griddoldur();
            griddoldur2();
            getir();
            double sy1 = 0;
            double sy2 = 0;
            double toplam;
            sy1 = Convert.ToInt32(textBox1.Text);
            sy2 = Convert.ToDouble(textBox2.Text);
            toplam = sy1 * sy2;
            label10.Text = toplam.ToString();

            label11.Text = textBox1.Text;


            int sy3 = 0;
            int sy4 = 0;
            int sonuç = 0;
            sy3 = Convert.ToInt32(label16.Text);
            sy4 = Convert.ToInt32(label11.Text);
            sonuç = sy3 - sy4;
            textBox4.Text = sonuç.ToString();

            }
            else
            {
                MessageBox.Show("Lütfen Alanları Doldurunuz...");
            }



        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
          
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void materialRaisedButton2_Click(object sender, EventArgs e)
        {
            güncelle();
            griddoldur();
        }

        private void materialRaisedButton3_Click(object sender, EventArgs e)
        {


            if (textBox3.Text != "")
            {
            MailMessage message = new MailMessage();
            SmtpClient istemci = new SmtpClient();
            istemci.Credentials = new NetworkCredential("iksvinfo@gmail.com", "iksvESTP34");
            istemci.Port = 587;
            istemci.Host = "smtp.gmail.com";
            istemci.EnableSsl = true;
            message.To.Add(textBox3.Text);
            message.From = new MailAddress(textBox3.Text);
            message.Subject = "E-FATURA";
            message.Body = "Müşteri Adı   : " + label15.Text + "\n" + "Müşteri Cari No    :" + label14.Text + "\n" + "Ürün Adı    :" + label13.Text + "\n" + "Ürün Barkod    :" + label12.Text + "\n" + "Ürün Miktarı   :" + label11.Text + "\n" + "Toplam Fiyat    :" + label10.Text;
            istemci.Send(message);
            MessageBox.Show("Dekont Gönderildi...");
            }
            else
            {
                MessageBox.Show("Lütfen Mail Adresi Giriniz...");
            }

           




















        }
    }
}
