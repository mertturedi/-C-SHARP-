﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proje_01.Tablolar
{
    public static class login
    {
        private static int ID;
        private static string Kadi;
        private static string Sifre;

        public static int id
        {
            get { return login.ID; }
            set { ID = value; }
        }

        public static string Kullaniciadi
        {
            get { return login.Kadi; }
            set { Kadi = value; }
        }

        public static string    sifre
        {
            get { return login.Sifre; }
            set { Sifre = value; }
        }
    }
}
